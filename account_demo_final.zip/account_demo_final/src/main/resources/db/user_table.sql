CREATE TABLE IF NOT EXISTS USER (
    USER_ID BIGINT PRIMARY KEY AUTO_INCREMENT,
    NAME VARCHAR(50) NOT NULL
);

INSERT INTO USER (NAME) VALUES
('John Doe'),
('Jane Smith'),
('Alice Brown'),
('Bob Johnson'),
('Charlie White'),
('Daisy Green'),
('Ethan Black'),
('Fiona Gray'),
('George Blue'),
('Hannah Gold'),
('Ivy Silver'),
('Jack Orange'),
('Karen Red'),
('Liam Violet'),
('Mona Pink'),
('Nathan Lime'),
('Olivia Teal'),
('Paul Aqua'),
('Quincy Yellow'),
('Rachel Purple');