package com.example.demo.service.impl;

import com.example.demo.entity.Account;
import com.example.demo.entity.AccountTransaction;
import com.example.demo.repository.AccountTransactionRepository;
import com.example.demo.service.AccountTransactionService;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AccountTransactionServiceImpl implements AccountTransactionService {

    @Autowired
    private AccountTransactionRepository accountTransactionRepository;

    @Override
    public Page<AccountTransaction> getTransactionsByAccountNumber(String accountNumber, Pageable pageable) {
        return accountTransactionRepository.findByAccount_AccountNumber(accountNumber, pageable);
    }
}