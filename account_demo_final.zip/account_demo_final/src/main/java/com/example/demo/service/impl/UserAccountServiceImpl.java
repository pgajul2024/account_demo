package com.example.demo.service.impl;

import com.example.demo.entity.Account;
import com.example.demo.entity.UserAccount;
import com.example.demo.repository.UserAccountRepository;
import com.example.demo.service.UserAccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class UserAccountServiceImpl implements UserAccountService {

    @Autowired
    private UserAccountRepository userAccountRepository;

    @Override
    public List<Account> getAccountsForUser(Long userId) {
        List<UserAccount> userAccounts = userAccountRepository.findByUser_UserId(userId);
        return userAccounts.stream()
                .map(UserAccount::getAccount)
                .collect(Collectors.toList());
    }

    @Override
    public List<Account> getAccountsForUser(Long userId, Pageable pageable) {
        Page<UserAccount> userAccounts = userAccountRepository.findByUser_UserId(userId, pageable);;
        return userAccounts.stream()
                .map(UserAccount::getAccount)
                .collect(Collectors.toList());
    }
}