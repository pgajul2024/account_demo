package com.example.demo.service;

import com.example.demo.entity.Account;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface AccountService {
    Page<Account> getAllAccountsByPage(Pageable pageable);
    List<Account> getAll();
    Account getAccountByNumber(String accountNumber);
}