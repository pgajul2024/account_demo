package com.example.demo.controller;

import com.example.demo.entity.Account;
import com.example.demo.entity.AccountTransaction;
import com.example.demo.service.AccountService;
import com.example.demo.service.AccountTransactionService;
import com.example.demo.service.UserAccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("accounts")
public class AccountController {

    @Autowired
    private AccountService accountService;

    @Autowired
    private AccountTransactionService accountTransactionService;

    @Autowired
    private UserAccountService userAccountService;

    @GetMapping("/users/{userId}")
    public List<Account> getAccountsForUser(@PathVariable Long userId) {
        return userAccountService.getAccountsForUser(userId);
    }

    @GetMapping("/users/{userId}/page")
    public List<Account> getAccountsForUserByPage(@PathVariable Long userId, @RequestParam(defaultValue = "0", required = false) int page,
                                            @RequestParam(defaultValue = "10", required = false) int size) {
        return userAccountService.getAccountsForUser(userId, PageRequest.of(page, size));
    }

    @GetMapping
    public Page<Account> getAllAccounts(@RequestParam(defaultValue = "0", required = false) int page,
                                        @RequestParam(defaultValue = "10", required = false) int size) {
        return accountService.getAllAccountsByPage(PageRequest.of(page, size));
    }

    @GetMapping("/{accountNumber}")
    public Account getAccountByNumber(@PathVariable String accountNumber) {
        return accountService.getAccountByNumber(accountNumber);
    }

    @GetMapping("/all")
    public List<Account> getAccountByNumber() {
        return accountService.getAll();
    }

    @GetMapping("/{accountNumber}/transactions")
    public Page<AccountTransaction> getTransactionsByAccountNumberWithKeyset(@PathVariable String accountNumber,
                                                                             @RequestParam(defaultValue = "0", required = false) int page,
                                                                             @RequestParam(defaultValue = "10", required = false) int size) {
        return accountTransactionService.getTransactionsByAccountNumber(accountNumber, PageRequest.of(page, size));
    }
}